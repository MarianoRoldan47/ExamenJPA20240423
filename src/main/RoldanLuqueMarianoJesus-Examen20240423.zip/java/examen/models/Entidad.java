package examen.models;

public class Entidad {

	public Entidad() {
		
	}
}
